//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FaceReconiction : NSObject

@property (strong, nonatomic)NSString *Foto1;
@property (strong, nonatomic)NSString *imgaenFoto2;
@property (strong, nonatomic)NSString *imgaenFoto2Renonocimiento;
@property (strong, nonatomic)NSString *_id;
@property (strong, nonatomic)NSString *Imagen;
@property (strong, nonatomic)NSString *Nom;
@property (strong, nonatomic)NSString *DNI;
@property (strong, nonatomic)NSString *Desapareguda;
@property (strong, nonatomic)NSString *Delincuent;
@property (strong, nonatomic)NSString *Pederasta;
@property (strong, nonatomic)NSString *Terrorista;
@property (strong, nonatomic)NSString *SeBusca;
@property (strong, nonatomic)NSString *Nacionalitat;
@property (strong, nonatomic)NSString *Pais;
@property (strong, nonatomic)NSString *Edad;
@property (strong, nonatomic)NSString *Sexe;
/*    

 

 */


- (id)initWithFoto1:(NSString *)aFoto1
         imgaenFoto2:(NSString *)aimgaenFoto2
        imgaenFoto2Renonocimiento:(NSString *)aimgaenFoto2Renonocimiento
        _id:(NSString *)a_id
      Imagen:(NSString *)aImagen
      Nom:(NSString *)aNom
     DNI:(NSString *)aDNI
     Desapareguda:(NSString *)aDesapareguda
     Delincuent:(NSString *)aDelincuent
    Pederasta:(NSString *)aPederasta
   Terrorista:(NSString *)aTerrorista
   SeBusca:(NSString *)aSeBusca
   Nacionalitat:(NSString *)aNacionalitat
 Pais:(NSString *)aPais
   Edad:(NSString *)aEdad
    Sexe:(NSString *)aSexe;



- (id)initWithDictionary:(NSDictionary *)dic;

@end
