//
//  LlistaReconeixementFacialTableViewController.m
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import "ViewController.h"
#import "ListReconeixementFacialCell.h"
#import "LlistaReconeixementFacialTableViewController.h"
#import "FaceReconiction.h"

#import "ViewController.h"
#import "AFHTTPRequestOperationManager.h"
#import "UIImageView+AFNetworking.h"
#import "LlistaReconeixementFacialTableViewController.h"


@interface LlistaReconeixementFacialTableViewController ()

@property (nonatomic, strong)NSArray *DATOSReconeixementFacial;
-(IBAction)UpdateFile:(id)sender;

@end

@implementation LlistaReconeixementFacialTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadDatos];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.DATOSReconeixementFacial.count;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 268.0f;
}


-(IBAction)UpdateFile:(id)sender
{
    
    NSURL *url;
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSArray *jsonArray = (NSArray *)responseObject;
        
        NSMutableArray *tempturismo = [[NSMutableArray alloc] init];
        
        for (NSDictionary *dic in jsonArray) {
            FaceReconiction *ListaFaceReconiction = [[FaceReconiction alloc] initWithDictionary:dic];
            [tempturismo addObject:ListaFaceReconiction];
        }
        
        
        self.DATOSReconeixementFacial = [[NSArray alloc] initWithArray:tempturismo];
        tempturismo = nil;
        
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
       
    }];
    
    [operation start];
}





- (void)loadDatos {
    
    NSURL *url;
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSArray *jsonArray = (NSArray *)responseObject;
        
        NSMutableArray *tempturismo = [[NSMutableArray alloc] init];
        
        for (NSDictionary *dic in jsonArray) {
            FaceReconiction *ListaFaceReconiction = [[FaceReconiction alloc] initWithDictionary:dic];
            [tempturismo addObject:ListaFaceReconiction];
        }
        
        
        self.DATOSReconeixementFacial = [[NSArray alloc] initWithArray:tempturismo];
        tempturismo = nil;
        
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
       
    }];
    
    [operation start];
}


@end
