//
//  SessionDataTask.m
//  ReconeixementFacial
//
//  Created by HackerMaster   on 16/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <CFNetwork/CFNetwork.h>
#import "ConectionMain.h"
#import "ViewController.h"
#import "SessionDataTask.h"


@interface SessionDataTask ()

@property (retain, nonatomic) NSMutableData *receivedData;

@property (retain, nonatomic) UIActivityIndicatorView *indicator;
@property (retain, nonatomic) UIButton *SendingInfo;
@property (retain, nonatomic) UIButton *RecivingiNFOdEPARTAMENTpolice;

@end


@implementation SessionDataTask
{
    NSURLConnection *ConectionMain;
    NSMutableURLRequest *request;
    UIActivityIndicatorView *indicator;
    NSURLSession *SessionResponse;
    NSURLResponse *Recivingresponse;
    NSURLSessionDownloadTask *DonloadRecivingresponse;
}

-(void)sessionconect{
    
    ConectionMain *URL;
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDownloadTask *downloadTask = [session downloadTaskWithRequest:request
                                                            completionHandler:
                                              ^(NSURL *location, NSURLResponse *response, NSError *error) {
                                                  NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
                                                  NSURL *documentsDirectoryURL = [NSURL fileURLWithPath:documentsPath];
                                                  NSURL *documentURL = [documentsDirectoryURL URLByAppendingPathComponent:[response
                                                                                                                           suggestedFilename]];
                                                  [[NSFileManager defaultManager] moveItemAtURL:location
                                                                                          toURL:documentURL
                                                                                          error:nil];
                                                  
                                                  NSString *SendingInfodString = [NSString stringWithFormat:@"%@:%@", _SendingInfo, _RecivingiNFOdEPARTAMENTpolice];
                                                  NSData * RecivingiNFOdEPARTAMENTpolice = [SendingInfodString dataUsingEncoding:NSUTF8StringEncoding];
                                                  NSString *base64EncodedCredential = [RecivingiNFOdEPARTAMENTpolice base64EncodedStringWithOptions:0];
                                                  NSString *DocumntauthSendingInfodString= [NSString stringWithFormat:@"Basic %@", base64EncodedCredential];
                                                  NSString *InfoFacePersonString;
                                                  
                                           

                                              }];
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    self.connection = connection;
    [connection autoContentAccessingProxy];
    
    
    [connection start];


    [downloadTask resume];
}


@end
