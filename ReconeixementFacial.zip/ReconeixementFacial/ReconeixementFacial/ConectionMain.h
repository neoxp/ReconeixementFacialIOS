//
//  ConectionMain.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 16/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>
#import <CFNetwork/CFNetwork.h>
#import "ViewController.h"

@interface ConectionMain : NSURLComponents <UINavigationControllerDelegate,
UIImagePickerControllerDelegate,NSURLConnectionDelegate, NSURLSessionStreamDelegate, NSURLProtocolClient, NSURLSessionDelegate, NSURLSessionDataDelegate, UIResponderStandardEditActions>{
    
    UIButton *response;
    
}
@property (retain, nonatomic) NSURLConnection *connection;

- (void)Recivingresponse;

@end
