<?php
    
    $link = mysqli_connect("mysql.webcindario.com", "facialpeople", "admin1234");
    
    mysqli_select_db($link, "facialpeople");
    
    $tildes = $link->query("SET NAMES 'utf8'");
    
    $result = mysqli_query($link, "SELECT * FROM RECONEIXEMENT FACIAL");
    
    mysqli_data_seek ($result, 10);
    
    $extraido= mysqli_fetch_array($result);
    
    echo "- id: ".$extraido['id']."<br/>";
    
    echo "- Name: ".$extraido['Name']."<br/>";
    
     echo "- Gastronomi: ".$extraido['Gastronomi']."<br/>";
    
    echo "- Ranking: ".$extraido['Ranking']."<br/>";
    
    echo "- location: ".$extraido['location']."<br/>";
    
     echo "- lat: ".$extraido['lat']."<br/>";
    
    echo "- lng: ".$extraido['lng']."<br/>";
    
    mysqli_free_result($result);
    
    mysqli_close($link);
    
?>
