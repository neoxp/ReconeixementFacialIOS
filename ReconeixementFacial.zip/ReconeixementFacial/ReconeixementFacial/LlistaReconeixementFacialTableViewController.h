//
//  LlistaReconeixementFacialTableViewController.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import <CFNetwork/CFNetwork.h>
#import <Contacts/Contacts.h>
#import <OpenAL/OpenAL.h>
#import <notify.h>
#import <sqlite3.h>
#import <sqlite3ext.h>

#import <Accelerate/Accelerate.h>


#import "ViewController.h"
#import "ListReconeixementFacialCell.h"
#import "LlistaReconeixementFacialTableViewController.h"

@interface LlistaReconeixementFacialTableViewController : UITableViewController<CIImageProcessorInput,CIImageProcessorOutput,NSFileManagerDelegate,UIImagePickerControllerDelegate,NSObject,NSCopying,NSSecureCoding,NSStreamDelegate,NSURLProtocolClient,NSURLConnectionDelegate,NSURLConnectionDataDelegate,NSURLSessionDownloadDelegate>{
    
    NSString *Stringtransform;
    NSString *StringLoading;
    
    NSString *StringLblmesaje1;
    NSString *StringLblmesaje2;
    NSString *StringLblmesaje3;
    
    
    NSString *StringimgaenFoto2Renonocimiento;
    
    NSString *StringFoto1;
    NSString *StringimgaenFoto2;
    
    
    NSString *StringbtnCamara;
    NSString *StringbtnStartReconeixementFacial;
    NSString *StringbtnEnviarInformacio;
    
    
    
    //////////////////////////////////
    
    NSString *Stringid;
    NSString *StringImagen;
    NSString *StringNom;
    NSString *StringDNI;
    NSString *StringDesapareguda;
    NSString *StringDelincuent;
    NSString *StringPederasta;
    NSString *StringTerrorista;
    NSString *StringSeBusca;
    NSString *StringNacionalitat;
    NSString *StringPais;
    NSString *StringEdad;
    NSString *StringSexe;
}


-(void)faceDetector;
-(void)markFaces:(UIImageView *)imagenCara withTransform:(CGAffineTransform) transform;







@end

