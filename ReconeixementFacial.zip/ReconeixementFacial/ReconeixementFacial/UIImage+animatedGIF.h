//
//  UIImage+animatedGIF.h
//  GeoComunicacion
//
//  Created by Hackermaster on 13/05/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface UIImage (animatedGIF)


+ (UIImage *)animatedImageWithAnimatedGIFData:(NSData *)theData;


+ (UIImage *)animatedImageWithAnimatedGIFURL:(NSURL *)theURL;

@end
