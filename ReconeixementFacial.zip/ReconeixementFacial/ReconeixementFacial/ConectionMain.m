//
//  ConectionMain.m
//  ReconeixementFacial
//
//  Created by HackerMaster   on 16/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import "ConectionMain.h"
#import "ViewController.h"
#import "SessionDataTask.h"

@interface ConectionMain ()
@property (retain, nonatomic) NSMutableData *receivedData;

@property (retain, nonatomic) UIActivityIndicatorView *indicator;
@property (retain, nonatomic) UIButton *InfoConect;

@end

@implementation ConectionMain
{
    NSString *pngData;
    NSString *syncResData;
    NSMutableURLRequest *request;
    UIActivityIndicatorView *indicator;
    NSURLSession *SessionResponse;
    NSURLResponse *Recivingresponse;
    NSURLSessionDownloadTask *DonloadRecivingresponse;

    
#define URL_CONECTION            @"http://facialpeople.webcindario.com/ConsultaBaseDeDades.php"
#define NO_CONNECTION  @"No Connection"
#define CONECTIONINFORMATION_RLS      @"CONECTION_INFORMATION
    
}

- (void)viewDidLoad {
    pngData = nil;
    indicator = nil;
     SessionResponse = nil;
     SessionResponse = nil;
     DonloadRecivingresponse = nil;
    
    [self initPB];
}

- (void)Recivingresponse{
    
  
    [self.connection cancel];
    
    
    NSMutableData *data = [[NSMutableData alloc] init];
    self.receivedData = data;
    [data autoContentAccessingProxy];
    
    NSURL *url = [NSURL URLWithString:@""];
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[url standardizedURL]];
    
 
    [request setHTTPMethod:@"POST"];
   
    NSString *postData = [[NSString alloc] initWithString:@"fname=example&lname=example"];
  
    
    [request setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
   
    [request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
  
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    self.connection = connection;
    [connection autoContentAccessingProxy];
    
   
    [connection start];
    
}


-(void)connection:(NSURLConnection *)connection didReceiveData:(NSString *)data{
    [self.receivedData appendData:data];
      [_receivedData appendData:connection];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    NSLog(@"%@" , error);
}


-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    
    NSString *htmlSTR = [[NSString alloc] initWithData:self.receivedData
                                              encoding:NSUTF8StringEncoding];
    NSLog(@"%@" , htmlSTR);
  
    response.enabled=  UIButtonTypeInfoDark;
    
    [indicator stopAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;
    
}



-(BOOL) setParams{
    
    if(SessionResponse && SessionResponse && DonloadRecivingresponse!= nil){
        
        [indicator startAnimating];
        
        request = [NSMutableURLRequest new];
        request.timeoutInterval = 20.0;
        [request setURL:[NSURL URLWithString:URL_CONECTION]];
        [request setHTTPMethod:@"POST"];
        
        NSString *boundary = @"---------------------------14737809831466499882746641449";
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
        [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
        [request setValue:@"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" forHTTPHeaderField:@"Accept"];
        [request setValue:@"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/536.26.14 (KHTML, like Gecko) Version/6.0.1 Safari/536.26.14" forHTTPHeaderField:@"User-Agent"];
        
        NSMutableData *body = [NSMutableData data];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"%@.png\"\r\n", @"Uploaded_file"] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
        
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        
        [request setHTTPBody:body];
        [request addValue:[NSString stringWithFormat:@"%d", [body length]] forHTTPHeaderField:@"Content-Length"];
        
        return TRUE;
        
    }else{
        
        response.enabled = UIButtonTypeInfoDark;
        
        return FALSE;
    }
}

- (void)SendImageFilespOLICE
{
    
    if( [self setParams]){
        
        NSError *error = nil;
        NSURLResponse *responseStr = nil;
        syncResData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseStr error:&error];
        NSString *returnString = [[NSString alloc] initWithData:syncResData encoding:NSUTF8StringEncoding];
        
        NSLog(@"ERROR %@", error);
        NSLog(@"RES %@", responseStr);
        
        NSLog(@"%@", returnString);
        
        if(error == nil){
            response.enabled = UIButtonTypeInfoDark;
        }
        
        [indicator stopAnimating];
        
    }
    

    
    if( [self setParams]){
        
        NSOperationQueue *queue = [[NSOperationQueue alloc]init];
        
        
        [NSURLConnection sendAsynchronousRequest:request
                                           queue:queue
                               completionHandler:^(NSURLResponse *urlResponse, NSData *data, NSError *error){
                                   NSLog(@"Completed");
                                   
                                  
                                   
                                   [indicator stopAnimating];
                                   [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;
                                   
                                   if (error) {
                                       NSLog(@"error:%@", error.localizedDescription);
                                   }
                                   
                               }];
    }
    
    
}

- (void)SebndingMail{
    
    if( [self setParams]){
        
        if([[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES]){
            
        };
        
    }
    
}

- (void)RecivindCentraliNFORMATION{
    
    if( [self setParams]){
        
        if([NSURLConnection connectionWithRequest:request delegate:self]){
            
        };
    }
    
}

-(void) initPB{
    indicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [self.InfoConect addSubview:indicator];
    [indicator bringSubviewToFront:self.InfoConect];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = TRUE;
}

#pragma mark NSURLConnection Delegate Methods

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {

    _receivedData = [[NSMutableData alloc] init];
}


- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
  
    return nil;
}




@end
