//
//  ViewController.m
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import "ViewController.h"
#import "ListReconeixementFacialCell.h"
#import "LlistaReconeixementFacialTableViewController.h"
#import "FaceReconiction.h"

#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>
#import <MessageUI/MessageUI.h>
#import <Messages/Messages.h>

#import <SpriteKit/SpriteKit.h>
#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>

#import "ResponseRequest.h"
#import "ConectionMain.h"
#import "ViewController.h"
#import "SessionDataTask.h"
#import "ViewController.h"
#import "SessionDataTask.h"
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>

@interface ViewController ()
{
    NSString *pngData;
    NSString *syncResData;
    NSMutableURLRequest *request;
    UIActivityIndicatorView *indicator;
    NSURLSession *SessionResponse;
    NSURLResponse *Recivingresponse;
    NSURLSessionDownloadTask *DonloadRecivingresponse;
    
}

#define URL_CONECTION            @"http://facialpeople.webcindario.com/ConsultaBaseDeDades.php"
#define NO_CONNECTION  @"No Connection"
#define CONECTIONINFORMATION_RLS      @"CONECTION_INFORMATION

- (void)abrirGaleria;
- (void)btnrecivirdatos;
- (void)ReeventInformcacioDeLaCentral;
- (void)faceDetector;
- (void)Recivingresponse;
- (void)SendImageFilespOLICE;

@property (strong, nonatomic) IBOutlet UIImageView *dataImageView;
@property (strong, nonatomic) IBOutlet UIImageView *urlImageView;
@property (strong, nonatomic) IBOutlet UIImageView *variableDurationImageView;


@property (strong, nonatomic) IBOutlet UIImageView *dataImageView1;
@property (strong, nonatomic) IBOutlet UIImageView *urlImageView1;
@property (strong, nonatomic) IBOutlet UIImageView *variableDurationImageView1;


@property (nonatomic) IBOutlet UIActivityIndicatorView *loadingProgressIndicator;

@property (nonatomic, retain) IBOutlet UILabel *Lblid;
@property (nonatomic, retain) IBOutlet UILabel *LblNOM;
@property (nonatomic, retain) IBOutlet UILabel *LblDNI;
@property (nonatomic, retain) IBOutlet UILabel *LblDesapareguda;
@property (nonatomic, retain) IBOutlet UILabel *LblDelincuent;
@property (nonatomic, retain) IBOutlet UILabel *LblStringPederasta;
@property (nonatomic, retain) IBOutlet UILabel *LblTerrorista;
@property (nonatomic, retain) IBOutlet UILabel *LblSeBusca;
@property (nonatomic, retain) IBOutlet UILabel *LblNacionalitat;
@property (nonatomic, retain) IBOutlet UILabel *LblPais;
@property (nonatomic, retain) IBOutlet UILabel *LblEdad;
@property (nonatomic, retain) IBOutlet UILabel *LblSexe;

////////////////////////////////////////////////////////////////////////////
@property (retain, nonatomic) NSMutableData *receivedData;
////////////////////////////////////////////////////////////////////////////
@property (retain, nonatomic) UIActivityIndicatorView *indicator;
@property (retain, nonatomic) UIButton *SendingInfo;
@property (retain, nonatomic) UIButton *RecivingiNFOdEPARTAMENTpolice;
@property (retain, nonatomic) UIButton *InfoConect;
@end

@implementation ViewController

@synthesize dataImageView;
////////////////////////////////////////////////////////////////////////////
@synthesize urlImageView,InformacionRebudadelacentralDepolicialbl;
@synthesize botonCamara,botonStartReconeixementFacial,botonEnviar,botonReeventInformcacioDeLaCentral;

////////////////////////////////////////////////////////////////////////////
@synthesize Foto1,FotoRstartReconeixementfacial1;
@synthesize Foto2,FotoRstartReconeixementfacial2;



- (void)abrirGaleria
{
    
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
   
    picker.delegate = self;
   
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
  
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:picker];
        [picker autoContentAccessingProxy];
        [popover presentPopoverFromRect:CGRectMake(200, 940.0, 0.0, 0.0)
                                 inView:self.view
               permittedArrowDirections:UIPopoverArrowDirectionAny
                               animated:YES];
    }
    else
        [self presentModalViewController:picker animated:YES];
}



-(void) initPB{
    _loadingProgressIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _loadingProgressIndicator.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2 , 40.0, 40.0);
    [self.InfoConect addSubview:_loadingProgressIndicator];
    [_indicator bringSubviewToFront:self.InfoConect];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = TRUE;
}



- (void)configureView {
    // Update the user interface for the detail item.
    if (self.detailItem1) {
        self.urlImageView.motionEffects = [self.detailItem1 description];
        self.dataImageView.motionEffects = [self.detailItem1 description];
        
        self.urlImageView1.motionEffects = [self.detailItem1 description];
        self.dataImageView1.motionEffects = [self.detailItem1 description];
    }
    if (self.detailItem2) {
        self.Lblid.text = [self.detailItem2 description];
    }
    if (self.detailItem3) {
       self.LblNOM.text = [self.detailItem3 description];
    }
    if (self.detailItem4) {
       self.LblDNI.text = [self.detailItem4 description];
    }
    if (self.detailItem5) {
       self.LblDesapareguda.text = [self.detailItem5 description];
    }
    if (self.detailItem6) {
        self.LblDelincuent.text = [self.detailItem6 description];
    }
    if (self.detailItem8) {
      self.LblStringPederasta.text = [self.detailItem8 description];
    }
    if (self.detailItem9) {
        self.LblTerrorista.text = [self.detailItem9 description];
    }
    
    if (self.detailItem10) {
        self.LblSeBusca.text = [self.detailItem10 description];
    }
    
    if (self.detailItem11) {
        self.LblPais.text = [self.detailItem11 description];
    }
    if (self.detailItem12) {
        self.LblEdad.text = [self.detailItem12 description];
    }
    if (self.detailItem13) {
        self.LblSexe.text = [self.detailItem13 description];
    }
    
}


- (void)setDetailItem1:(NSString *)newDetailItem1 {
    if (_detailItem1 != newDetailItem1) {
        _detailItem1 = newDetailItem1;
        
        // Update the view.
        [self configureView];
    }
}


- (void)setDetailItem2:(NSString *)newDetailItem2 {
    if (_detailItem2 != newDetailItem2) {
        _detailItem2 = newDetailItem2;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem3:(NSString *)newDetailItem3 {
    if (_detailItem3 != newDetailItem3) {
        _detailItem3 = newDetailItem3;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem4:(NSString *)newDetailItem4 {
    if (_detailItem4 != newDetailItem4) {
        _detailItem4 = newDetailItem4;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem5:(NSString *)newDetailItem5 {
    if (_detailItem5 != newDetailItem5) {
        _detailItem5 = newDetailItem5;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem6:(NSString *)newDetailItem6 {
    if (_detailItem6 != newDetailItem6) {
        _detailItem6 = newDetailItem6;
        
        // Update the view.
        [self configureView];
    }
}


- (void)setDetailItem7:(NSString *)newDetailItem7 {
    if (_detailItem7 != newDetailItem7) {
        _detailItem7 = newDetailItem7;
        
        // Update the view.
        [self configureView];
    }
}


- (void)setDetailItem8:(NSString *)newDetailItem8 {
    if (_detailItem8 != newDetailItem8) {
        _detailItem8 = newDetailItem8;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem9:(NSString *)newDetailItem9 {
    if (_detailItem9 != newDetailItem9) {
        _detailItem9 = newDetailItem9;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem10:(NSString *)newDetailItem10 {
    if (_detailItem10 != newDetailItem10) {
        _detailItem10 = newDetailItem10;
        
        // Update the view.
        [self configureView];
    }
}


- (void)setDetailItem11:(NSString *)newDetailItem11 {
    if (_detailItem11 != newDetailItem11) {
        _detailItem11 = newDetailItem11;
        
        // Update the view.
        [self configureView];
    }
}

- (void)setDetailItem12:(NSString *)newDetailItem12 {
    if (_detailItem12 != newDetailItem12) {
        _detailItem12 = newDetailItem12;
        
        // Update the view.
        [self configureView];
    }
}
- (void)setDetailItem13:(NSString *)newDetailItem13 {
    if (_detailItem13 != newDetailItem13) {
        _detailItem13 = newDetailItem13;
        
        // Update the view.
        [self configureView];
    }
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}



#pragma mark - UI Display and Actions
- (void)hideUIElements:(BOOL)shouldHide animated:(BOOL)shouldAnimate {
    CGFloat alpha = shouldHide ? 0.0f : 1.0f;
    
    if (shouldAnimate) {
        [UIView animateWithDuration:2.0 delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            self.dataImageView.alpha = alpha;
        } completion:NULL];
    } else {
        [self.dataImageView setAlpha:alpha];
    }
}

- (void)btnrecivirdatos {
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];

    picker.delegate = self;
    
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
  
    
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        UIPopoverController *popover = [[UIPopoverController alloc] initWithContentViewController:picker];
        [picker autoContentAccessingProxy];
        [popover presentPopoverFromRect:CGRectMake(200, 940.0, 0.0, 0.0)
                                 inView:self.view
               permittedArrowDirections:UIPopoverArrowDirectionAny
                               animated:YES];
    }
    else
        [self presentModalViewController:picker animated:YES];
}

- (IBAction)btnCamara:(id)sender
{
    UIImagePickerController * picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    [self presentModalViewController:picker animated:YES];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
   
    [picker dismissModalViewControllerAnimated:YES];
    //FOTO1
    urlImageView.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    dataImageView.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    //FOTO2
    _urlImageView1.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    _dataImageView1.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
}





- (void)dealloc
{
    [urlImageView autoContentAccessingProxy];
    [dataImageView autoContentAccessingProxy];
     [_urlImageView1 autoContentAccessingProxy];
     [_dataImageView1 autoContentAccessingProxy];
    [botonCamara autoContentAccessingProxy];
    

    [super autoContentAccessingProxy];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    InformacionRebudadelacentralDepolicialbl.text = @"REVENT LA INFORMACÍO DE LA CENTRAL DEL RECONEIXEMENT FACIAL";
    if ([[segue identifier] isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath;
        NSString *object;
        LlistaReconeixementFacialTableViewController *controller = (LlistaReconeixementFacialTableViewController *)[[segue destinationViewController] topViewController];
        [controller setRefreshControl:object];
        controller.navigationItem.leftBarButtonItem = self.splitViewController.displayModeButtonItem;
        controller.navigationItem.leftItemsSupplementBackButton = YES;
        botonEnviar.enabled = YES;
        botonEnviar.hidden = NO;
        botonEnviar.hidden=NO;
        InformacionRebudadelacentralDepolicialbl.text = @"REVENT LA INFORMACÍO DE LA CENTRAL DEL RECONEIXEMENT FACIAL";
        
        
        
    }

}

- (void)Recivingresponse{
    
    
    [self.connection cancel];
    
    
    NSMutableData *data = [[NSMutableData alloc] init];
    self.receivedData = data;
    [data autoContentAccessingProxy];
    
    NSURL *url = [NSURL URLWithString:@"http://facialpeople.webcindario.com/ConsultaBaseDeDades.php"];
    
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[url standardizedURL]];
    
    
    [request setHTTPMethod:@"GET"];
    
    NSString *postData = [[NSString alloc] initWithString:@"fname=example&lname=ReconeixementFacial"];
    
    
    [request setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    
    [request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    NSURLConnection *connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    self.connection = connection;
    [connection start];
    
    
    [request setHTTPMethod:@"POST"];
    
    postData = [[NSString alloc] initWithString:@"fname=example&lname=ReconeixementFacial"];
    
    
    [request setValue:@"application/x-www-form-urlencoded; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    
    
    [request setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    self.connection = connection;


    [connection start];
    
}


-(void)connection:(NSURLConnection *)connection didReceiveData:(NSString *)data{
    [self.receivedData appendData:data];
    [_receivedData appendData:connection];
}

-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    NSLog(@"%@" , error);
}


-(void)connectionDidFinishLoading:(NSURLConnection *)connection{
    
    NSString *htmlSTR = [[NSString alloc] initWithData:self.receivedData
                                              encoding:NSUTF8StringEncoding];
    NSLog(@"%@" , htmlSTR);
    
    response.enabled=  UIButtonTypeInfoDark;
    
    [indicator stopAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;
    
}



-(BOOL) setParams{
    
    if(SessionResponse && SessionResponse && DonloadRecivingresponse!= nil){
        
        [_loadingProgressIndicator startAnimating];
        
        request = [NSMutableURLRequest new];
        request.timeoutInterval = 20.0;
        [request setURL:[NSURL URLWithString:URL_CONECTION]];
        [request setHTTPMethod:@"POST"];
        
        NSString *boundary = @"---------------------------14737809831466499882746641449";
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
        [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
        [request setValue:@"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" forHTTPHeaderField:@"Accept"];
        [request setValue:@"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/536.26.14 (KHTML, like Gecko) Version/6.0.1 Safari/536.26.14" forHTTPHeaderField:@"User-Agent"];
        
        NSMutableData *body = [NSMutableData data];
        [body appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"uploaded_file\"; filename=\"%@.png\"\r\n", @"Uploaded_file"] dataUsingEncoding:NSUTF8StringEncoding]];
        
        [body appendData:[@"Content-Type: application/octet-stream\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        
        
        
        [request setHTTPBody:body];
        
        return TRUE;
        
    }else{
        
        response.enabled = UIButtonTypeInfoDark;
        
        return FALSE;
    }
}

- (void)SendImageFilespOLICE
{
    
    if( [self setParams]){
        NSError *error = nil;
        NSURLResponse *responseStr = nil;
        syncResData = [NSURLConnection sendSynchronousRequest:request returningResponse:&responseStr error:&error];
        NSString *returnString = [[NSString alloc] initWithData:syncResData encoding:NSUTF8StringEncoding];
        
        NSLog(@"ERROR %@", error);
        NSLog(@"RES %@", responseStr);
        
        NSLog(@"%@", returnString);
        
        if(error == nil){
            response.enabled = UIButtonTypeInfoDark;
        }
        
        [_loadingProgressIndicator stopAnimating];
        
    }
    
    
    
    if( [self setParams]){
        
        NSOperationQueue *queue = [[NSOperationQueue alloc]init];
        
        
        [NSURLConnection sendAsynchronousRequest:request
                                           queue:queue
                               completionHandler:^(NSURLResponse *urlResponse, NSData *data, NSError *error){
                                   NSLog(@"Completed");
                                   
                                   
                                   
                                   [_loadingProgressIndicator stopAnimating];
                                   [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;
                                   
                                   if (error) {
                                       NSLog(@"error:%@", error.localizedDescription);
                                   }
                                   
                               }];
    }
    
    
}

- (void)SebndingMail{
    
    if( [self setParams]){
        
        if([[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:YES]){
            
        };
        
    }
    
}

- (void)RecivindCentraliNFORMATION{
    
    if( [self setParams]){
        
        if([NSURLConnection connectionWithRequest:request delegate:self]){
            
        };
    }
    
}


#pragma mark NSURLConnection Delegate Methods

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    
    _receivedData = [[NSMutableData alloc] init];
}


- (NSCachedURLResponse *)connection:(NSURLConnection *)connection
                  willCacheResponse:(NSCachedURLResponse*)cachedResponse {
    
    return nil;
}


- (void)ReeventInformcacioDeLaCentral{
    
    if (UIButtonTypeInfoDark == urlImageView == _variableDurationImageView) {
        _RecivingiNFOdEPARTAMENTpolice = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 35, 35)];
        [_RecivingiNFOdEPARTAMENTpolice setBackgroundImage:[UIImage imageNamed:@"recibir_informaciondelaCentral.png"] forState:UIControlStateNormal];
        [_RecivingiNFOdEPARTAMENTpolice addTarget:self action:@selector(messageButtonTapped) forControlEvents:UIControlEventAllEvents];
        UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:_RecivingiNFOdEPARTAMENTpolice];
        self.navigationItem.leftBarButtonItem = leftBarButtonItem;
        
        _loadingProgressIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _loadingProgressIndicator.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2 , 40.0, 40.0);
        [self.InfoConect addSubview:_loadingProgressIndicator];
        [_loadingProgressIndicator bringSubviewToFront:self.InfoConect];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = TRUE;
        
    }
    else if (UIButtonTypeCustom == _urlImageView1 == _variableDurationImageView1) {
        
        _RecivingiNFOdEPARTAMENTpolice = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 35, 35)];
        [_RecivingiNFOdEPARTAMENTpolice setBackgroundImage:[UIImage imageNamed:@"icono_Resposta_informaciondelaCentral.png"] forState:UIControlStateNormal];
        [_RecivingiNFOdEPARTAMENTpolice addTarget:self action:@selector(messageButtonTapped) forControlEvents:UIControlEventAllEvents];
        UIBarButtonItem *leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:_RecivingiNFOdEPARTAMENTpolice];
        self.navigationItem.leftBarButtonItem = leftBarButtonItem;
        
        _loadingProgressIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _loadingProgressIndicator.frame = CGRectMake(([UIScreen mainScreen].bounds.size.width)/2, ([UIScreen mainScreen].bounds.size.height)/2 , 40.0, 40.0);
   
        [self.InfoConect addSubview:_indicator];
        [_loadingProgressIndicator bringSubviewToFront:self.InfoConect];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = TRUE;
        
        
    }
    
    [self faceDetector];
}


#pragma mark  Boto Accio ReeventInformcacioDeLaCentral Reconeixement Facial

-(IBAction)botonReeventInformcacioDeLaCentral:(id)sender {
    
    [self ReeventInformcacioDeLaCentral];
    [self faceDetector];
    [self Recivingresponse];
}

#pragma mark Reconeixement facial Action

-(void)faceDetector
{
    if (UIImagePickerControllerCameraDeviceRear==CIDetectorSmile == urlImageView == TRUE) {
        UIImageView *imagen = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"EmiliMarquesFores.png"]];
        UIImageView *image = [[NSBundle mainBundle] URLForResource:@"EmiliMarquesFores" withExtension:@"png"];
        self.dataImageView.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image]];
        self.urlImageView.image = [UIImage animatedImageWithAnimatedGIFURL:image];
        
        image = [[NSBundle mainBundle] URLForResource:@"StartReconeixementEmiliMarquesFores" withExtension:@"png"];
        self.FotoRstartReconeixementfacial1.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial1];
  
        
        [self.view addSubview:urlImageView];
        
        
          UIImageView *imagen2 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"StartReconeixementEmiliMarquesFores.png"]];
        [self.view addSubview:_variableDurationImageView];
       

    }
    
    else if (UIImagePickerControllerCameraDeviceRear<=CIDetectorSmile == _urlImageView1 == TRUE) {
        
        UIImageView *imagen3 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"mama1.png"]];
        [self.view addSubview:_urlImageView1];
     
        
        UIImageView *image3  = [[NSBundle mainBundle] URLForResource:@"mama1" withExtension:@"png"];
        self.dataImageView1.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image3]];
        self.urlImageView1.image = [UIImage animatedImageWithAnimatedGIFURL:image3];
        
        image3 = [[NSBundle mainBundle] URLForResource:@"StartReconeixemenFacialMama" withExtension:@"png"];
        self.FotoRstartReconeixementfacial2.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial2];
         UIImageView *imagen4 = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"StartReconeixemenFacialMama.png"]];
        [self.view addSubview:_variableDurationImageView1];
       
        
    }
    
  



}

#pragma mark Reconeixement Facial Boto Accio

- (IBAction)btnstaartreconeixementFacial:(id)sender {
  
    
    UIImageView *image = [[NSBundle mainBundle] URLForResource:@"EmiliMarquesFores" withExtension:@"png"];
    self.dataImageView.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image]];
    self.urlImageView.image = [UIImage animatedImageWithAnimatedGIFURL:image];
    
    image = [[NSBundle mainBundle] URLForResource:@"StartReconeixementEmiliMarquesFores" withExtension:@"png"];
    self.FotoRstartReconeixementfacial1.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial1];
    
    
    
    UIImageView *image1  = [[NSBundle mainBundle] URLForResource:@"mama1" withExtension:@"png"];
    self.dataImageView1.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image]];
    self.urlImageView1.image = [UIImage animatedImageWithAnimatedGIFURL:image];
    
    image1 = [[NSBundle mainBundle] URLForResource:@"StartReconeixemenFacialMama" withExtension:@"png"];
    self.FotoRstartReconeixementfacial2.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial2];
    // RECONIEXMNET FACIAL CARA 1
    if (UIImagePickerControllerCameraDeviceRear<=CIDetectorSmile == urlImageView == TRUE) {
        CIImage *imagen = [CIImage imageWithCGImage:urlImageView.image.CGImage];
        CIDetector *detector = [CIDetector detectorOfType:CIDetectorTypeFace context:nil options:[NSDictionary dictionaryWithObject:CIDetectorAccuracyHigh forKey:CIDetectorAccuracy]];
        
        
        NSArray *features = [detector featuresInImage:imagen];
        
        for (CIFaceFeature *faceFeature in features) {
            
            CGFloat faceWidth = faceFeature.bounds.size.width;
            
            UIView *faceView = [[UIView alloc] initWithFrame:faceFeature.bounds];
            
            
            faceView.layer.borderWidth = 1;
            faceView.layer.borderColor = [[UIColor blueColor] CGColor];
            
            [self.view addSubview:faceView];
            
            
            if (faceFeature.hasRightEyePosition) {
                UIView *rightEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.rightEyePosition.x - faceWidth * 0.15, faceFeature.rightEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                
                rightEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                rightEye.center = faceFeature.rightEyePosition;
                
                rightEye.layer.cornerRadius = faceWidth * 0.15;
                [self.view addSubview:rightEye];
            }
            
            if (faceFeature.hasLeftEyePosition) {
                UIView *leftEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.leftEyePosition.x - faceWidth * 0.15, faceFeature.leftEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                
                leftEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                leftEye.center = faceFeature.leftEyePosition;
                
                leftEye.layer.cornerRadius = faceWidth * 0.15;
                [self.view addSubview:leftEye];
            }
            
            
            if (faceFeature.hasMouthPosition) {
                UIView *mouth = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.mouthPosition.x - faceWidth * 0.20, faceFeature.mouthPosition.y - faceWidth * 0.20, faceWidth * 0.40, faceWidth * 0.40)];
                
                mouth.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.4];
                mouth.center = faceFeature.mouthPosition;
                
                mouth.layer.cornerRadius = faceWidth * 0.20;
                [self.view addSubview:mouth];
            }
     
        
        else if (UIImagePickerControllerCameraDeviceRear<=CIDetectorSmile == urlImageView == dataImageView  == TRUE) {
            CIImage *imagen1 = [CIImage imageWithCGImage:dataImageView.image.CGImage];
            CIDetector *detector2 = [CIDetector detectorOfType:CIDetectorTypeFace context:nil options:[NSDictionary dictionaryWithObject:CIDetectorAccuracyHigh forKey:CIDetectorAccuracy]];
            
            
            NSArray *features1 = [detector featuresInImage:imagen];
            
            for (CIFaceFeature *faceFeature1 in features) {
                
                CGFloat faceWidth = faceFeature1.bounds.size.width;
                
                UIView *faceView = [[UIView alloc] initWithFrame:faceFeature1.bounds];
                
                
                faceView.layer.borderWidth = 1;
                faceView.layer.borderColor = [[UIColor blueColor] CGColor];
                
                [self.view addSubview:faceView];
                
                
                if (faceFeature1.hasRightEyePosition) {
                    UIView *rightEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.rightEyePosition.x - faceWidth * 0.15, faceFeature1.rightEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                    
                    rightEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                    rightEye.center = faceFeature1.rightEyePosition;
                    
                    rightEye.layer.cornerRadius = faceWidth * 0.15;
                    [self.view addSubview:rightEye];
                }
                
                if (faceFeature1.hasLeftEyePosition) {
                    UIView *leftEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.leftEyePosition.x - faceWidth * 0.15, faceFeature1.leftEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                    
                    leftEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                    leftEye.center = faceFeature1.leftEyePosition;
                    
                    leftEye.layer.cornerRadius = faceWidth * 0.15;
                    [self.view addSubview:leftEye];
                }
                
                
                if (faceFeature1.hasMouthPosition) {
                    UIView *mouth = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.mouthPosition.x - faceWidth * 0.20, faceFeature1.mouthPosition.y - faceWidth * 0.20, faceWidth * 0.40, faceWidth * 0.40)];
                    
                    mouth.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.4];
                    mouth.center = faceFeature1.mouthPosition;
                    
                    mouth.layer.cornerRadius = faceWidth * 0.20;
                    [self.view addSubview:mouth];
                }
            }
            
         }
            
            // RECONEIXEMENT FACIAL CARA 2
            
            if (UIImagePickerControllerCameraDeviceRear<=CIDetectorSmile == _urlImageView1 == TRUE) {
                CIImage *imagen1 = [CIImage imageWithCGImage:_urlImageView1.image.CGImage];
                CIDetector *detector = [CIDetector detectorOfType:CIDetectorTypeFace context:nil options:[NSDictionary dictionaryWithObject:CIDetectorAccuracyHigh forKey:CIDetectorAccuracy]];
                
                
                NSArray *features2 = [detector featuresInImage:imagen1];
                
                for (CIFaceFeature *faceFeature2 in features2) {
                    
                    CGFloat faceWidth = faceFeature2.bounds.size.width;
                    
                    UIView *faceView = [[UIView alloc] initWithFrame:faceFeature.bounds];
                    
                    
                    faceView.layer.borderWidth = 1;
                    faceView.layer.borderColor = [[UIColor blueColor] CGColor];
                    
                    [self.view addSubview:faceView];
                    
                    
                    if (faceFeature.hasRightEyePosition) {
                        UIView *rightEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.rightEyePosition.x - faceWidth * 0.15, faceFeature.rightEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                        
                        rightEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                        rightEye.center = faceFeature.rightEyePosition;
                        
                        rightEye.layer.cornerRadius = faceWidth * 0.15;
                        [self.view addSubview:rightEye];
                    }
                    
                    if (faceFeature.hasLeftEyePosition) {
                        UIView *leftEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.leftEyePosition.x - faceWidth * 0.15, faceFeature.leftEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                        
                        leftEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                        leftEye.center = faceFeature.leftEyePosition;
                        
                        leftEye.layer.cornerRadius = faceWidth * 0.15;
                        [self.view addSubview:leftEye];
                    }
                    
                    
                    if (faceFeature.hasMouthPosition) {
                        UIView *mouth = [[UIView alloc] initWithFrame:CGRectMake(faceFeature.mouthPosition.x - faceWidth * 0.20, faceFeature.mouthPosition.y - faceWidth * 0.20, faceWidth * 0.40, faceWidth * 0.40)];
                        
                        mouth.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.4];
                        mouth.center = faceFeature.mouthPosition;
                        
                        mouth.layer.cornerRadius = faceWidth * 0.20;
                        [self.view addSubview:mouth];
                    }
                    
                    
                    else if (UIImagePickerControllerCameraDeviceRear<=CIDetectorSmile == _urlImageView1 == _dataImageView1  == TRUE) {
                        CIImage *imagen4 = [CIImage imageWithCGImage:_dataImageView1.image.CGImage];
                        CIDetector *detector2 = [CIDetector detectorOfType:CIDetectorTypeFace context:nil options:[NSDictionary dictionaryWithObject:CIDetectorAccuracyHigh forKey:CIDetectorAccuracy]];
                        
                        
                        NSArray *features4 = [detector featuresInImage:imagen4];
                        
                        for (CIFaceFeature *faceFeature1 in features) {
                            
                            CGFloat faceWidth = faceFeature1.bounds.size.width;
                            
                            UIView *faceView = [[UIView alloc] initWithFrame:faceFeature1.bounds];
                            
                            
                            faceView.layer.borderWidth = 1;
                            faceView.layer.borderColor = [[UIColor blueColor] CGColor];
                            
                            [self.view addSubview:faceView];
                            
                            
                            if (faceFeature1.hasRightEyePosition) {
                                UIView *rightEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.rightEyePosition.x - faceWidth * 0.15, faceFeature1.rightEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                                
                                rightEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                                rightEye.center = faceFeature1.rightEyePosition;
                                
                                rightEye.layer.cornerRadius = faceWidth * 0.15;
                                [self.view addSubview:rightEye];
                            }
                            
                            if (faceFeature1.hasLeftEyePosition) {
                                UIView *leftEye = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.leftEyePosition.x - faceWidth * 0.15, faceFeature1.leftEyePosition.y - faceWidth * 0.15, faceWidth * 0.3, faceWidth * 0.3)];
                                
                                leftEye.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.4];
                                leftEye.center = faceFeature1.leftEyePosition;
                                
                                leftEye.layer.cornerRadius = faceWidth * 0.15;
                                [self.view addSubview:leftEye];
                            }
                            
                            
                            if (faceFeature1.hasMouthPosition) {
                                UIView *mouth = [[UIView alloc] initWithFrame:CGRectMake(faceFeature1.mouthPosition.x - faceWidth * 0.20, faceFeature1.mouthPosition.y - faceWidth * 0.20, faceWidth * 0.40, faceWidth * 0.40)];
                                
                                mouth.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.4];
                                mouth.center = faceFeature1.mouthPosition;
                                
                                mouth.layer.cornerRadius = faceWidth * 0.20;
                                [self.view addSubview:mouth];
                            }
                        }
                        
                    }
                }
            }
        }
    }
    [self configureView];
    [self ReeventInformcacioDeLaCentral];
    [self faceDetector];
    [self Recivingresponse];
    [self SendImageFilespOLICE];
    [self viewDidLoad];
}


- (IBAction)btnEnviarinformacio:(id)sender {
    
    botonEnviar.enabled = YES;
    botonEnviar.hidden = NO;
    botonEnviar.hidden=NO;
    InformacionRebudadelacentralDepolicialbl.text = @"ENVIANT RECONEIXEMENT RECIVINT A LA CENTRAL";
    
    
    if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
        mailer.mailComposeDelegate = self;
        
        [mailer setSubject:@"ENVIANT RECONEIXEMENT RECONEIXEMENT FACIAL"];
   

      
        NSArray *toRecipients = [NSArray arrayWithObjects:@"", nil];
        
        [mailer setToRecipients:toRecipients];
       
    
        [mailer setSubject:Stringid];
        [mailer setSubject:StringImagen];
        [mailer setSubject:StringNom];
        [mailer setSubject:StringDNI];
        [mailer setSubject:StringDesapareguda];
        [mailer setSubject:StringPederasta];
        [mailer setSubject:StringTerrorista];
        [mailer setSubject:StringSeBusca];
        [mailer setSubject:StringNacionalitat];
        [mailer setSubject:StringPais];
        [mailer setSubject:StringEdad];
        [mailer setSubject:StringSexe];
        
        
        
       
       
        NSString *emailBody = @"<br>INFORMCÍO DEL RECONEIXEMENT FACIAL</br><br><img src='http://facialpeople.webcindario.com/StartReconeixementEmiliMarquesFores.png' /></br><br>ID: 2</br><br>NOM: EMILI MARQÉS FORES</br><br>DNI: 47624530-V</br><br>DELINCUENT: NO ES DELINCUENT</br><br>TERORISTA: NO ES TERRORISTA</br><br>PEDERASTA: NO ES PEDERASTA</br><br>SE BUSCA: NO SE BUSCA</br><br>NACIONALITAT: ESPANYOL</br><br>PAIS: ESPANYA</br><br>EDAD: 33 ANYS</br><brSEXE: HOME</br><br>ESPERANT EL RENVIAMENT DE LA RESPOSTA DE LA CENTRAL DEL COS DE POLICÍA</br>";
  
        
        
        [mailer setMessageBody:emailBody isHTML:YES];
        
        
        
        [self presentViewController:mailer animated:YES completion:nil];
    }
 
    
    else if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
        mailer.mailComposeDelegate = self;
        
        [mailer setSubject:@"REVENT LA INFORMACÍO DE LA CENTRAL DEL RECONEIXEMENT FACIAL "];
       
     NSString *emailBody2 = @"<br>RECIVINT INFORMCÍO DEL RECONEIXEMENT FACIAL DE LA CENTRAL DEL COS DE POLICÍA </br><br><img src='http://facialpeople.webcindario.com/EmiliMarquesFores.png' /></br><br>ID: 2</br><br>NOM: EMILI MARQÉS FORES</br><br>DNI: 47624530-V</br><br>DELINCUENT: NO ES DELINCUENT</br><br>TERORISTA: NO ES TERRORISTA</br><br>PEDERASTA: NO ES PEDERASTA</br><br>SE BUSCA: NO SE BUSCA</br><br>NACIONALITAT: ESPANYOL</br><br>PAIS: ESPANYA</br><br>EDAD: 33 ANYS</br><brSEXE: HOME</br>";
        
        [self presentViewController:mailer animated:YES completion:nil];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"REVENT LA INFORMACÍO DE LA CENTRALL"
                                                        message:@"INFORMACÍO REBUDA"
                                                       delegate:nil
                                              cancelButtonTitle:@"CONFIRMAT"
                                              otherButtonTitles: nil];
        [alert show];
    }
}


- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    NSString *mensaje;
    switch (result)
    {
        case MFMailComposeResultCancelled: mensaje = @"ERROR NO SE HA ENVIADO";
            break;
        case MFMailComposeResultSaved: mensaje = @"Enviando la informacion correctamente";
            break;
        case MFMailComposeResultSent: mensaje = @"Reciviendo la informacíon de la central";
            break;
        case MFMailComposeResultFailed: mensaje = @"No se han recivido los daots";
            break;
        default:
            break;
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"MENSAJE INFORMACIÓN DE LA IMAGEN HA SIDO ENVIADA"
                                                    message:mensaje
                                                   delegate:self
                                          cancelButtonTitle:@"Aceptar"
                                          otherButtonTitles: nil];
    [alert show];
    InformacionRebudadelacentralDepolicialbl.hidden=TRUE;
    botonEnviar.hidden = YES;
    InformacionRebudadelacentralDepolicialbl.hidden = YES;
  
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}




- (void)viewDidLoad
{
    [super viewDidLoad];
    [self startCount];
    [self configureView];
    [self ReeventInformcacioDeLaCentral];
    [self faceDetector];
    [self Recivingresponse];
    [self SendImageFilespOLICE];
    
  
    
    
    
    self.PrgView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
    
    [self.view addSubview:self.LblLoading];
    

    UIImageView *image = [[NSBundle mainBundle] URLForResource:@"EmiliMarquesFores" withExtension:@"png"];
    self.dataImageView.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image]];
    self.urlImageView.image = [UIImage animatedImageWithAnimatedGIFURL:image];
    
    image = [[NSBundle mainBundle] URLForResource:@"StartReconeixementEmiliMarquesFores" withExtension:@"png"];
    self.FotoRstartReconeixementfacial1.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial1];
    
    
    
   UIImageView *image1  = [[NSBundle mainBundle] URLForResource:@"mama1" withExtension:@"png"];
    self.dataImageView1.image = [UIImage animatedImageWithAnimatedGIFData:[NSData dataWithContentsOfURL:image]];
    self.urlImageView1.image = [UIImage animatedImageWithAnimatedGIFURL:image];
    
    image1 = [[NSBundle mainBundle] URLForResource:@"StartReconeixemenFacialMama" withExtension:@"png"];
    self.FotoRstartReconeixementfacial2.image = [UIImage animatedImageWithAnimatedGIFURL:FotoRstartReconeixementfacial2];

    
}




- (void)comenzarAnimacion {
    
    CGFloat x = (CGFloat) (arc4random() % (int) self.view.bounds.size.width);
    CGFloat y = (CGFloat) (arc4random() % (int) self.view.bounds.size.height);
    
    CGPoint posicion = CGPointMake(x, y);
    
    UIViewAnimationOptions options = UIViewAnimationOptionCurveEaseInOut | UIViewAnimationOptionBeginFromCurrentState;
    
    [UIView animateWithDuration:1.5 delay:0 options:options animations:^{
        
        
        
    } completion:^(BOOL finished) {
        
        
    }];
    
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (void)updateUI:(NSTimer *)timer
{
    static int count =0; count++;
    
    if (count <=10)
    {
        self.LblLoading.text = [NSString stringWithFormat:@"ESPERE SISPLAU.CARGANT LA IMATGE...",count*10];
        [self.myTimer timeInterval];
        self.myTimer = nil;
        self.PrgView.progress = (float)count/10.0f;
        
    }
    
   if (count >=10)
    {
        self.LblLoading.text = [NSString stringWithFormat:@"START RECONEIXEMENT FACIAL DE LA IMATGE...",count*10];
        [self.myTimer timeInterval];
        self.myTimer = nil;
        self.PrgView.progress = (float)count/10.0f;
    }
    
    if (count <=10)
    {
        self.PercerLabel.text = [NSString stringWithFormat:@"%d %%",count*10];
        self.PrgView.progress = (float)count/10.0f;
    }
   else
    {
        [self.myTimer invalidate];
        self.myTimer = nil;
        self.LblLoading.text = [NSString stringWithFormat:@"ENVIANT LA INFORMACÍO A LA CENTRAL"];
    }
    
}

- (void)startCount {
    self.myTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateUI:) userInfo:nil repeats:YES];
}


@end
