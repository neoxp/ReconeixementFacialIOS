//
//  ViewController.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import <CFNetwork/CFNetwork.h>
#import <Contacts/Contacts.h>
#import <OpenAL/OpenAL.h>
#import <notify.h>
#import <sqlite3.h>
#import <sqlite3ext.h>
#import <MessageUI/MessageUI.h>
#import <Accelerate/Accelerate.h>
#import <SpriteKit/SpriteKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import <AVFoundation/AVFoundation.h>
#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>



#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import <AVFoundation/AVFoundation.h>
#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>


#import "LlistaReconeixementFacialTableViewController.h"

@interface ViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate,MFMailComposeViewControllerDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UINavigationControllerDelegate,
UIImagePickerControllerDelegate,NSURLConnectionDelegate, NSURLSessionStreamDelegate, NSURLProtocolClient, NSURLSessionDelegate, NSURLSessionDataDelegate, UIResponderStandardEditActions>
{
    
    AVAudioPlayer *reproductor;
    NSString *titulo;
    UISegmentedControl *segmentedControl;
    NSString *CargaEfectosDelJuego;
    
    NSArray *ArrayEfectos;
    NSInteger selectedButton;
    NSArray*sounds;
    NSArray*soundStrings;
    
    //////////////////
    NSString *Stringid;
    NSString *StringImagen;
    NSString *StringNom;
    NSString *StringDNI;
    NSString *StringDesapareguda;
    NSString *StringDelincuent;
    NSString *StringPederasta;
    NSString *StringTerrorista;
    NSString *StringSeBusca;
    NSString *StringNacionalitat;
    NSString *StringPais;
    NSString *StringEdad;
    NSString *StringSexe;
    NSString *Stringtransform;
    NSString *StringLoading;
    
    NSString *StringLblmesaje1;
    NSString *StringLblmesaje2;
    NSString *StringLblmesaje3;
    
    
    NSString *StringimgaenFoto2Renonocimiento;
    
    NSString *StringFoto1;
    NSString *StringimgaenFoto2;
    
    
    NSString *StringbtnCamara;
    NSString *StringbtnStartReconeixementFacial;
    NSString *StringbtnEnviarInformacio;
    
    
  
    UIButton *response;
    
    
}
@property (retain, nonatomic) NSURLConnection *connection;

- (void)Recivingresponse;




@property (strong, nonatomic) NSString *detailItem1;
@property (strong, nonatomic) NSString *detailItem2;
@property (strong, nonatomic) NSString *detailItem3;
@property (strong, nonatomic) NSString *detailItem4;
@property (strong, nonatomic) NSString *detailItem5;
@property (strong, nonatomic) NSString *detailItem6;
@property (strong, nonatomic) NSString *detailItem7;
@property (strong, nonatomic) NSString *detailItem8;
@property (strong, nonatomic) NSString *detailItem9;
@property (strong, nonatomic) NSString *detailItem10;
@property (strong, nonatomic) NSString *detailItem11;
@property (strong, nonatomic) NSString *detailItem12;
@property (strong, nonatomic) NSString *detailItem13;



@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel2;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel3;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel4;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel5;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel6;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel7;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel8;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel9;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel10;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel11;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel12;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel13;

-(void)faceDetector;
-(void)markFaces:(UIImageView *)imagenCara withTransform:(CGAffineTransform) transform;



@property (strong, nonatomic) LlistaReconeixementFacialTableViewController *detailViewController;


@property (nonatomic) NSInteger selectedButton;
@property (nonatomic, weak) IBOutlet UILabel *outputlabel;
@property (nonatomic, strong) NSTimer *myTimer;
@property (weak, nonatomic) IBOutlet UILabel *PercerLabel;

@property (strong, nonatomic) IBOutlet UILabel *LblLoading;
@property (strong, nonatomic) IBOutlet UIProgressView *PrgView;
@property (strong, nonatomic)          NSString *LblLoadingText;
@property (strong, nonatomic)          NSString *PrgViewText;

- (void)comenzarAnimacion;

////////////////////////////////////////////////////////////////////////////

@property (nonatomic, weak) IBOutlet  UIButton *botonCamara;
@property (nonatomic, weak) IBOutlet  UIButton *botonStartReconeixementFacial;
@property (nonatomic, weak) IBOutlet  UIButton *botonEnviar;


@property (nonatomic, weak) IBOutlet  UIButton *botonReeventInformcacioDeLaCentral;

////////////////////////////////////////////////////////////////////////////

@property (nonatomic, weak) IBOutlet  UIImageView *Foto1;

@property (nonatomic, weak) IBOutlet  UIImageView *FotoRstartReconeixementfacial1;

////////////////////////////////////////////////////////////////////////////

@property (nonatomic, weak) IBOutlet  UIImageView *Foto2;

@property (nonatomic, weak) IBOutlet  UIImageView *FotoRstartReconeixementfacial2;

@property (strong, nonatomic) IBOutlet UILabel *InformacionRebudadelacentralDepolicialbl;


@property (nonatomic) float progressValue;

- (void)startProgress:(id)sender;

-(void)increaseProgressValue;

@end

