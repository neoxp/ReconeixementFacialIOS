//
//  ListReconeixementFacialCell.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <UIKit/UIKit.h>
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>
#import <ImageIO/ImageIO.h>
#import <CFNetwork/CFNetwork.h>
#import <Contacts/Contacts.h>
#import <OpenAL/OpenAL.h>
#import <notify.h>
#import <sqlite3.h>
#import <sqlite3ext.h>

#import <Accelerate/Accelerate.h>

@interface ListReconeixementFacialCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *Loading;


@property (nonatomic, retain) IBOutlet UIImageView *FotoPersona;

@property (nonatomic, retain) IBOutlet UILabel *Lblid;
@property (nonatomic, retain) IBOutlet UILabel *LblNOM;
@property (nonatomic, retain) IBOutlet UILabel *LblDNI;
@property (nonatomic, retain) IBOutlet UILabel *LblDesapareguda;
@property (nonatomic, retain) IBOutlet UILabel *LblDelincuent;
@property (nonatomic, retain) IBOutlet UILabel *LblStringPederasta;
@property (nonatomic, retain) IBOutlet UILabel *LblTerrorista;
@property (nonatomic, retain) IBOutlet UILabel *LblSeBusca;
@property (nonatomic, retain) IBOutlet UILabel *LblNacionalitat;
@property (nonatomic, retain) IBOutlet UILabel *LblPais;
@property (nonatomic, retain) IBOutlet UILabel *LblEdad;
@property (nonatomic, retain) IBOutlet UILabel *LblSexe;



@property (nonatomic, retain) IBOutlet UIButton *btnEnviarInformacio;
@end
