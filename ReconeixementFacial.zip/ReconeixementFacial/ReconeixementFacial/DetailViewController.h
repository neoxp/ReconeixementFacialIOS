//
//  DetailViewController.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "FaceReconiction.h"

@interface DetailViewController : UIViewController<MKMapViewDelegate>{
    
    BOOL _doneInitialZoom;
    MKMapView *mapView;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic) FaceReconiction *ListaFaceReconiction;
@end
