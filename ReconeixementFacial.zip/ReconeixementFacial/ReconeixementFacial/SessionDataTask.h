//
//  SessionDataTask.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 16/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <UIKit/UIKit.h>
#import <CFNetwork/CFNetwork.h>
#import "ViewController.h"

@interface SessionDataTask : NSURLSessionDataTask <UINavigationControllerDelegate,
UIImagePickerControllerDelegate,NSURLConnectionDelegate, NSURLSessionStreamDelegate, NSURLProtocolClient, NSURLSessionDelegate, NSURLSessionDataDelegate, UIResponderStandardEditActions>{
}
@property (retain, nonatomic) NSURLConnection *connection;
-(void)sessionconect;

@end
