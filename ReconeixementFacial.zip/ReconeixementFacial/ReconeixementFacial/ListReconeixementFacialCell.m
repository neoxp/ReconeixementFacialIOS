//
//  ListReconeixementFacialCell.m
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import "ListReconeixementFacialCell.h"

@implementation ListReconeixementFacialCell

@synthesize Lblid = _Lblid;
@synthesize FotoPersona = _FotoPersona;
@synthesize LblNOM= _LblNOM;
@synthesize LblDNI = _LblDNI;
@synthesize LblDesapareguda = _LblDesapareguda;
@synthesize LblDelincuent = _LblDelincuent;
@synthesize LblStringPederasta = _LblStringPederasta;
@synthesize LblTerrorista = _LblTerrorista;
@synthesize LblSeBusca = _LblSeBusca;
@synthesize LblNacionalitat = _LblNacionalitat;
@synthesize LblPais = _LblPais;
@synthesize LblEdad = _LblEdad;
@synthesize LblSexe = _LblSexe;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.Lblid.text = _Lblid;
         self.FotoPersona.image = _FotoPersona;
         self.LblNOM.text = _LblNOM;
         self.LblDNI.text = _LblDNI;
         self.LblDesapareguda.text = _LblDesapareguda;
         self.LblDelincuent.text = _LblDelincuent;
         self.LblStringPederasta.text = _LblStringPederasta;
          self.LblTerrorista.text = _LblTerrorista;
          self.LblSeBusca.text = _LblSeBusca;
         self.LblNacionalitat.text = _LblNacionalitat;
         self.LblPais.text = _LblPais;
         self.LblEdad.text = _LblEdad;
        self.LblSexe.text = _LblSexe;
    }
    return self;
}

- (void)awakeFromNib
{
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
}

@end
