//
//  AppDelegate.h
//  ReconeixementFacial
//
//  Created by HackerMaster   on 8/7/17.
//  Copyright © 2017 appdevelopment.es. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

#import "ViewController.h"
#import "ListReconeixementFacialCell.h"
#import "LlistaReconeixementFacialTableViewController.h"
#import "FaceReconiction.h"

#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>
#import <MessageUI/MessageUI.h>
#import <Messages/Messages.h>

#import <SpriteKit/SpriteKit.h>
#import "UIImage+animatedGIF.h"
#import <ImageIO/ImageIO.h>

#import "ResponseRequest.h"
#import "ConectionMain.h"
#import "ViewController.h"
#import "SessionDataTask.h"
#import "ViewController.h"
#import "SessionDataTask.h"
#import <CoreImage/CoreImage.h>
#import <QuartzCore/QuartzCore.h>


@class ViewController;
@class ListReconeixementFacialCell;
@class LlistaReconeixementFacialTableViewController;
@class FaceReconiction;


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) ViewController *listReconeixementFacialCell;
@property (strong, nonatomic) LlistaReconeixementFacialTableViewController *llistaReconeixementFacialTableViewController;
@property (strong, nonatomic) FaceReconiction *faceReconiction;

- (void)saveContext;


@end

