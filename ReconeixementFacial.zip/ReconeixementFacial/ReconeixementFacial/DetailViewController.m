//
//  DetailViewController.m
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import "DetailViewController.h"

#import "UIImageView+AFNetworking.h"

@interface DetailViewController ()
@property (nonatomic, retain) IBOutlet UIImageView *FotoPersona;
@property (nonatomic, retain) IBOutlet UILabel *Lblid;
@property (nonatomic, retain) IBOutlet UILabel *LblNOM;
@property (nonatomic, retain) IBOutlet UILabel *LblDNI;
@property (nonatomic, retain) IBOutlet UILabel *LblDesapareguda;
@property (nonatomic, retain) IBOutlet UILabel *LblDelincuent;
@property (nonatomic, retain) IBOutlet UILabel *LblStringPederasta;
@property (nonatomic, retain) IBOutlet UILabel *LblTerrorista;
@property (nonatomic, retain) IBOutlet UILabel *LblSeBusca;
@property (nonatomic, retain) IBOutlet UILabel *LblNacionalitat;
@property (nonatomic, retain) IBOutlet UILabel *LblPais;
@property (nonatomic, retain) IBOutlet UILabel *LblEdad;
@property (nonatomic, retain) IBOutlet UILabel *LblSexe;

@end

@implementation DetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.FotoPersona setImageWithURL:[NSURL URLWithString:self.ListaFaceReconiction.imgaenFoto2Renonocimiento]
               placeholderImage:[UIImage imageNamed:@"Catedral_de_Tortosa.jpg"]];
    
    self.Lblid = [self.ListaFaceReconiction _id];
    
     self.LblNOM = [self.ListaFaceReconiction Nom];
     self.LblDNI = [self.ListaFaceReconiction DNI];
      self.LblDesapareguda = [self.ListaFaceReconiction Desapareguda];
     self.LblDelincuent.text = self.ListaFaceReconiction.Delincuent;
     self.LblStringPederasta.text = self.ListaFaceReconiction.Pederasta;
     self.LblTerrorista.text = self.ListaFaceReconiction.Terrorista;
     self.LblSeBusca.text = self.ListaFaceReconiction.SeBusca;
     self.LblNacionalitat.text = self.ListaFaceReconiction.Nacionalitat;
     self.LblPais.text = self.ListaFaceReconiction.Pais;
     self.LblEdad.text = self.ListaFaceReconiction.Edad;
     self.LblSexe.text = self.ListaFaceReconiction.Sexe;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}



@end
