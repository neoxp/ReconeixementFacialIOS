//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//


#import "FaceReconiction.h"

@implementation FaceReconiction

- (id)initWithFoto1:(NSString *)aFoto1
        imgaenFoto2:(NSString *)aimgaenFoto2
imgaenFoto2Renonocimiento:(NSString *)aimgaenFoto2Renonocimiento
                _id:(NSString *)a_id
             Imagen:(NSString *)aImagen
                Nom:(NSString *)aNom
                DNI:(NSString *)aDNI
       Desapareguda:(NSString *)aDesapareguda
         Delincuent:(NSString *)aDelincuent
          Pederasta:(NSString *)aPederasta
         Terrorista:(NSString *)aTerrorista
            SeBusca:(NSString *)aSeBusca
       Nacionalitat:(NSString *)aNacionalitat
               Pais:(NSString *)aPais
               Edad:(NSString *)aEdad
               Sexe:(NSString *)aSexe {
    self = [super init];
    
    if (self) {
        self.Foto1 = aFoto1;
        self.imgaenFoto2 = aimgaenFoto2;
        self.imgaenFoto2Renonocimiento = aimgaenFoto2Renonocimiento;
        self._id = a_id;
        self.Imagen = aImagen;
        self.Nom = aNom;
        self.DNI = aDNI;
        self.Desapareguda = aDesapareguda;
        self.Delincuent = aDelincuent;
        self.Pederasta = aPederasta;
        self.Terrorista = aTerrorista;
        self.SeBusca = aSeBusca;
        self.Nacionalitat = aNacionalitat;
        self.Pais = aPais;
        self.Edad = aEdad;
        self.Sexe = aSexe;
    }
    
    return self;
}




- (id)initWithDictionary:(NSDictionary *)dic {
    self = [self initWithFoto1:@"Foto1" imgaenFoto2:@"imgaenFoto2" imgaenFoto2Renonocimiento:@"imgaenFoto2Renonocimiento" _id:@"id" Imagen:@"Imagen" Nom:@"Nom" DNI:@"DNI" Desapareguda:@"Desapareguda" Delincuent:@"Delincuent" Pederasta:@"Pederasta" Terrorista:@"Terrorista" SeBusca:@"SeBusca" Nacionalitat:@"Nacionalitat" Pais:@"Pais" Edad:@"Edad" Sexe:@"Sexe"];
    return self;
}

- (id)init {
     self = [self initWithFoto1:@"Undifined" imgaenFoto2:@"Undifined" imgaenFoto2Renonocimiento:@"Undifined" _id:@"Undifined" Imagen:@"Undifined" Nom:@"Undifined" DNI:@"Undifined" Desapareguda:@"Undifined" Delincuent:@"Undifined" Pederasta:@"Undifined" Terrorista:@"Undifined" SeBusca:@"Undifined" Nacionalitat:@"Undifined" Pais:@"Pais" Edad:@"Undifined" Sexe:@"Undifined"];
    return self;

   
}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@ : %@", self.Foto1, self.imgaenFoto2, self.imgaenFoto2Renonocimiento,self._id,self.imgaenFoto2Renonocimiento,self.Nom,self.DNI,self.Desapareguda,self.Delincuent,self.Pederasta,self.imgaenFoto2Renonocimiento,self.Terrorista,self.SeBusca,self.Nacionalitat,self.Pais,self.Edad,self.Sexe, self.description];
}

@end
